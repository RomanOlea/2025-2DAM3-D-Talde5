package DatuController;

import java.util.ArrayList;

import DAO.WorkoutsDao;
import Modelo.AldagaiGlobalak;
import Modelo.Workout;

public class WorkoutDC {

    // 🔹 Workout guztiak lortzeko metodoa (konektatuta dagoenean)
    public ArrayList<Workout> lortuWorkout() {
        ArrayList<Workout> workoutList = new ArrayList<>();

        if (AldagaiGlobalak.konektatuta) {
            // 🔹 Firestore datu basetik workout guztiak lortu
            WorkoutsDao woDao = new WorkoutsDao();
            workoutList = woDao.lortuWorkOuts();
        }

        return workoutList;
    }

    // 🔹 Mailaren arabera workout-ak lortzeko metodoa
    public ArrayList<Workout> lortuWorkoutMailarenArabera(String level) {
        ArrayList<Workout> workoutList = new ArrayList<>();

        if (AldagaiGlobalak.konektatuta) {
            // 🔹 Firestore datu basetik mailaren arabera workout-ak lortu
            WorkoutsDao woDao = new WorkoutsDao();
            workoutList = woDao.lortuWorkOutsLVL(level);
        }

        return workoutList;
    }
}
