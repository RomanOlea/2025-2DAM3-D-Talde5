package DatuController;

import java.util.ArrayList;

import DAO.ExerciseDao;
import Modelo.AldagaiGlobalak;
import Modelo.Exercise;

public class ExerciseDC {

    // 🔹 Workout baten ariketak lortzeko metodoa
    public ArrayList<Exercise> lortuAriketak(String workoutId) {
        ArrayList<Exercise> exerciseList = new ArrayList<>();

        if (AldagaiGlobalak.konektatuta) {
            // 🔹 Konektatuta badago, Firestore datu basetik lortu
            ExerciseDao exDao = new ExerciseDao();
            exerciseList = exDao.lortuWorkoutarenAriketak(workoutId);

        } else {
            // 🔹 Ez badago konektatuta, ariketak lokaletik kargatuko lirateke (etorkizunean)
            System.out.println("⚠️ Ez dago konektatuta: ariketak lokaletik kargatu beharko dira.");
        }

        return exerciseList;
    }
}
