package DatuController;

import DAO.UserDao;
import Modelo.AldagaiGlobalak;

public class UserDC {

    private final UserDao userDao;

    public UserDC() {
        this.userDao = new UserDao();
    }

    // 🔹 Erabiltzailea logeatu emailaren arabera
    public void ErabiltzaileaLogeatu(String email) {
        AldagaiGlobalak.logeatutakoErabiltzailea = userDao.lortuErabiltzailea(email);
    }

    // 🔹 Login datuak ondo dauden egiaztatu (email eta pasahitza)
    public boolean loginDataOndo(String email, String psw) {
        if (!AldagaiGlobalak.konektatuta) {
            System.out.println(" Ez dago konexiorik datu basera!");
            return false;
        }
        return userDao.loginDataOndo(email, psw);
    }
}
