package DatuController;

import java.util.ArrayList;
import DAO.WorkoutHistoryDao;
import Modelo.WorkoutHistory;

public class WHistoryDC {

    private WorkoutHistoryDao workoutHistoryDao = new WorkoutHistoryDao();

    // 🔹 Erabiltzaile baten historial guztia lortu (IDaren arabera)
    public ArrayList<WorkoutHistory> lortuHistorialak(int userId) throws Exception {
        return workoutHistoryDao.lortuHistorialak(userId);
    }

    // 🔹 Erabiltzaile baten historial berria gehitu
    public void gehituHistoriala(int userId, WorkoutHistory historial) throws Exception {
        workoutHistoryDao.gehituHistoriala(userId, historial);
    }
}
