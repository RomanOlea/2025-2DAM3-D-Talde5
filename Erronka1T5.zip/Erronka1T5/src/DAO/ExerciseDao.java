package DAO;

import java.util.ArrayList;
import java.util.List;

import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.CollectionReference;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.QueryDocumentSnapshot;

import Modelo.Exercise;
import Modelo.KonexioaDB;
import Modelo.Workout;

public class ExerciseDao {
    
    // 🔹 Workout baten ariketak lortu (workout ID baten arabera)
    public ArrayList<Exercise> lortuWorkoutarenAriketak(String id) {

        ArrayList<Exercise> exercises = new ArrayList<>();

        KonexioaDB kon = new KonexioaDB();
        Firestore db = kon.konektatuDB();

        try {
            // Workout dokumentua hartu
            DocumentReference docRef = db.collection("workouts").document(id);
            ApiFuture<DocumentSnapshot> querySnapshot = docRef.get();
            DocumentSnapshot document = querySnapshot.get();

            if (document.exists()) {
                // Azpikollekzioa: "Exercises"
                CollectionReference arCol = docRef.collection("Exercises");
                List<QueryDocumentSnapshot> ars = arCol.get().get().getDocuments();

                // Ariketa bakoitza irakurri eta listan gorde
                for (QueryDocumentSnapshot ar : ars) {
                    Exercise ex = new Exercise(
                            Integer.parseInt(ar.getId()),
                            ar.getString("name"),
                            (ar.getLong("series") != null) ? ar.getLong("series").intValue() : 0,
                            (ar.getLong("repeticiones") != null) ? ar.getLong("repeticiones").intValue() : 0,
                            ar.getString("photo"), // Ariketaren argazkiaren bidea edo URLa
                            (ar.getLong("time in seg") != null) ? ar.getLong("time in seg").intValue() : 0,
                            Integer.parseInt(id),
                            ar.getString("desc")
                    );
                    exercises.add(ex);
                }
            }

        } catch (Exception e) {
            System.out.println("❌ Errorea Firebase ariketak lortzean: " + e.getMessage());
        }

        return exercises;
    }

    // 🔹 Workout guztietako ariketa guztiak lortu
    public ArrayList<Exercise> lortuAriketaGuztiak() {

        ArrayList<Exercise> ariketak = new ArrayList<>();
        ArrayList<Workout> workouts;
        WorkoutsDao woDao = new WorkoutsDao();

        KonexioaDB kon = new KonexioaDB();
        Firestore db = kon.konektatuDB();

        try {
            // Workout guztiak lortu
            workouts = woDao.lortuWorkOuts();

            // Workout bakoitzetik ariketak atera
            for (Workout wo : workouts) {
                String id = wo.getId();
                DocumentReference docRef = db.collection("workouts").document(id);
                ApiFuture<DocumentSnapshot> querySnapshot = docRef.get();
                DocumentSnapshot document = querySnapshot.get();

                if (document.exists()) {
                    CollectionReference arCol = docRef.collection("Exercises");
                    List<QueryDocumentSnapshot> ars = arCol.get().get().getDocuments();

                    for (QueryDocumentSnapshot ar : ars) {
                        Exercise ex = new Exercise(
                                Integer.parseInt(ar.getId()),
                                ar.getString("name"),
                                (ar.getLong("series") != null) ? ar.getLong("series").intValue() : 0,
                                (ar.getLong("repeticiones") != null) ? ar.getLong("repeticiones").intValue() : 0,
                                ar.getString("photo"), // Argazkiaren URLa
                                (ar.getLong("time in seg") != null) ? ar.getLong("time in seg").intValue() : 0,
                                Integer.parseInt(id),
                                ar.getString("desc")
                        );
                        ariketak.add(ex);
                    }
                }
            }

        } catch (Exception e) {
            System.out.println("❌ Errorea Firebase datuak lortzean: " + e.getMessage());
        }

        return ariketak;
    }
}
