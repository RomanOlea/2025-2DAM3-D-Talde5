package DAO;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.CollectionReference;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.QueryDocumentSnapshot;
import com.google.cloud.firestore.QuerySnapshot;

import Modelo.KonexioaDB;
import Modelo.WorkoutHistory;

public class WorkoutHistoryDao {

    // 🔹 Erabiltzaile baten workout historial osoa lortzeko
    public ArrayList<WorkoutHistory> lortuHistorialak(int userId) throws Exception {
        ArrayList<WorkoutHistory> historial = new ArrayList<>();
        Firestore db = null;

        try {
            // Konexioa ireki
            KonexioaDB kon = new KonexioaDB();
            db = kon.konektatuDB();

            // Erabiltzailearen "historicalWorkouts" azpikolekzioa hartu
            CollectionReference historialRef = db.collection("users")
                    .document(String.valueOf(userId))
                    .collection("historicalWorkouts");

            // Datu guztiak jaso
            ApiFuture<QuerySnapshot> future = historialRef.get();
            List<QueryDocumentSnapshot> docs = future.get().getDocuments();

            // Dokumentu bakoitza WorkoutHistory bihurtu
            for (QueryDocumentSnapshot doc : docs) {
                String date = doc.getString("date");
                String level = doc.getString("level");
                String workoutName = doc.getString("workoutName");
                Long timeLong = doc.getLong("time");
                Long percentageLong = doc.getLong("percentage");

                int time = timeLong != null ? timeLong.intValue() : 0;
                int percentage = percentageLong != null ? percentageLong.intValue() : 0;

                // Objektua sortu eta gehitu listara
                WorkoutHistory h = new WorkoutHistory(userId, date, level, workoutName, time);
                h.setPercentage(percentage);
                historial.add(h);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Konexioa itxi
            if (db != null) db.close();
        }

        return historial;
    }

    // 🔹 Workout berria gehitu historialean
    public void gehituHistoriala(int userId, WorkoutHistory historial) throws Exception {
        Firestore db = null;
        try {
            // Konexioa ireki
            KonexioaDB kon = new KonexioaDB();
            db = kon.konektatuDB();

            // Erabiltzailearen "historicalWorkouts" azpikolekzioa hartu
            CollectionReference historialRef = db.collection("users")
                    .document(String.valueOf(userId))
                    .collection("historicalWorkouts");

            // Firestore-k ID automatikoa sortzen du
            DocumentReference newHistorial = historialRef.document();

            // Datuak prestatu
            Map<String, Object> data = new HashMap<>();
            data.put("date", historial.getDate());
            data.put("level", historial.getLevel());
            data.put("workoutName", historial.getName());
            data.put("time", historial.getTotalDuration());
            data.put("percentage", historial.getPercentage());

            // Datuak gorde
            newHistorial.set(data).get();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Konexioa itxi
            if (db != null) db.close();
        }
    }
}
