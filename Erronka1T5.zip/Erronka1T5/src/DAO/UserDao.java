package DAO;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.Query;
import com.google.cloud.firestore.QueryDocumentSnapshot;
import com.google.cloud.firestore.QuerySnapshot;
import com.google.cloud.firestore.CollectionReference;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.WriteResult;

import Modelo.KonexioaDB;
import Modelo.User;

public class UserDao {

    private final Firestore db;

    // 🔹 Datu-basearekin konexioa hasieratu
    public UserDao() {
        this.db = KonexioaDB.konektatuDB();
    }

    // 🔹 Login datuak zuzenak diren egiaztatu
    public boolean loginDataOndo(String email, String psw) {
        boolean loginOk = false;
        try {
            Query consulta = db.collection("users")
                    .whereEqualTo("email", email)
                    .whereEqualTo("password", psw);

            ApiFuture<QuerySnapshot> querySnapshot = consulta.get();
            List<QueryDocumentSnapshot> documents = querySnapshot.get().getDocuments();

            if (!documents.isEmpty()) {
                loginOk = true; // erabiltzailea aurkitu da
            }
        } catch (Exception e) {
            System.out.println("❌ Errorea loginDataOndo metodoan: " + e.getMessage());
        }
        return loginOk;
    }

    // 🔹 Erabiltzaile berri bat gorde (erregistroa)
    public void erabiltzaileaRegistratu(User erabiltzailea) {
        try {
            CollectionReference users = db.collection("users");

            // Datuak map batean gorde
            Map<String, Object> user = new HashMap<>();
            user.put("name", erabiltzailea.getName());
            user.put("lastName", erabiltzailea.getlastName());
            user.put("birth", erabiltzailea.getBirthDate());
            user.put("email", erabiltzailea.getEmail());
            user.put("password", erabiltzailea.getPassword());
            user.put("trainer", erabiltzailea.isTrainer());
            user.put("level", erabiltzailea.getLevel());

            // ID automatikoa kalkulatu (beste erabiltzaileen kopurua + 1)
            int id = UsuarioKop() + 1;
            DocumentReference usuarioNew = users.document(String.valueOf(id));

            // Erabiltzailea gorde
            ApiFuture<WriteResult> writeResult = usuarioNew.set(user);

            // Sortu historial huts bat (gero workout historiala gordetzeko)
            CollectionReference historialCol = usuarioNew.collection("historialDeWorkouts");
            Map<String, Object> historial = new HashMap<>();
            historial.put("HISTORIAL", "Documento 0 ez erabili");
            historialCol.document("0").set(historial);

            System.out.println("✅ Erabiltzailea ondo erregistratu da: " + writeResult.get().getUpdateTime());
        } catch (Exception e) {
            System.out.println("❌ Errorea erabiltzailea erregistratzean: " + e.getMessage());
        }
    }

    // 🔹 Erabiltzaile kopurua itzuli
    public int UsuarioKop() {
        int kop = 0;
        try {
            ApiFuture<QuerySnapshot> query = db.collection("users").get();
            QuerySnapshot querySnapshot = query.get();
            kop = querySnapshot.size();
        } catch (Exception e) {
            System.out.println("❌ Errorea erabiltzaileak zenbatzean: " + e.getMessage());
        }
        return kop;
    }

    // 🔹 Emailaren arabera erabiltzailearen IDa lortu
    public int lortuId(String email) {
        int id = 0;
        try {
            Query consulta = db.collection("users").whereEqualTo("email", email);
            ApiFuture<QuerySnapshot> querySnapshot = consulta.get();
            List<QueryDocumentSnapshot> documents = querySnapshot.get().getDocuments();
            for (QueryDocumentSnapshot document : documents) {
                id = Integer.parseInt(document.getId());
            }
        } catch (Exception e) {
            System.out.println("❌ Errorea lortuId metodoan: " + e.getMessage());
        }
        return id;
    }

    // 🔹 Erabiltzaile guztiak zerrendan itzuli
    public ArrayList<User> lortuErabiltzaileak() {
        ArrayList<User> erabiltzaileak = new ArrayList<>();
        try {
            ApiFuture<QuerySnapshot> query = db.collection("users").get();
            QuerySnapshot querySnapshot = query.get();

            for (QueryDocumentSnapshot document : querySnapshot.getDocuments()) {
                User erabiltzailea = new User(
                        Integer.parseInt(document.getId()),
                        document.getString("name"),
                        document.getString("lastName"),
                        document.getString("email"),
                        document.getString("password"),
                        document.getBoolean("trainer"),
                        document.getDate("birth"),
                        document.getString("level")
                );
                erabiltzaileak.add(erabiltzailea);
            }
        } catch (Exception e) {
            System.out.println("❌ Errorea lortuErabiltzaileak metodoan: " + e.getMessage());
        }
        return erabiltzaileak;
    }

    // 🔹 Email baten arabera erabiltzailearen datuak lortu
    public User lortuErabiltzailea(String email) {
        User user = null;
        try {
            Query consulta = db.collection("users").whereEqualTo("email", email);
            ApiFuture<QuerySnapshot> querySnapshot = consulta.get();
            List<QueryDocumentSnapshot> documents = querySnapshot.get().getDocuments();

            if (!documents.isEmpty()) {
                QueryDocumentSnapshot doc = documents.getFirst();
                user = new User(
                        Integer.parseInt(doc.getId()),
                        doc.getString("name"),
                        doc.getString("lastName"),
                        doc.getString("email"),
                        doc.getString("password"),
                        doc.getBoolean("trainer"),
                        doc.getDate("birth"),
                        doc.getString("level")
                );
            }
        } catch (Exception e) {
            System.out.println("❌ Errorea lortuErabiltzailea metodoan: " + e.getMessage());
        }
        return user;
    }

    // 🔹 Email bat dagoen ala ez egiaztatu
    public boolean emailArtuta(String email) {
        boolean emailArtuta = false;
        try {
            Query consulta = db.collection("users").whereEqualTo("email", email);
            ApiFuture<QuerySnapshot> querySnapshot = consulta.get();
            List<QueryDocumentSnapshot> documents = querySnapshot.get().getDocuments();
            emailArtuta = !documents.isEmpty();
        } catch (Exception e) {
            System.out.println("❌ Errorea emailArtuta metodoan: " + e.getMessage());
        }
        return emailArtuta;
    }
}
