package DAO;

import java.util.ArrayList;
import java.util.List;

import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.Query;
import com.google.cloud.firestore.QueryDocumentSnapshot;
import com.google.cloud.firestore.QuerySnapshot;

import Modelo.KonexioaDB;
import Modelo.Workout;

public class WorkoutsDao {

    // 🔹 Workout guztiak datu-basetik lortzeko metodoa
    public ArrayList<Workout> lortuWorkOuts() {
        ArrayList<Workout> workouts = new ArrayList<>();

        try {
            // Konexioa sortu
            KonexioaDB konexioa = new KonexioaDB();
            Firestore db = konexioa.konektatuDB();

            // "workouts" kolekzioa hartu
            ApiFuture<QuerySnapshot> query = db.collection("workouts").get();
            QuerySnapshot querySnapshot = query.get();
            List<QueryDocumentSnapshot> workoutList = querySnapshot.getDocuments();

            // Dokumentu bakoitza Workout objektu bihurtu
            for (QueryDocumentSnapshot workout : workoutList) {
                Workout w = new Workout(
                    workout.getId(),
                    workout.getString("name"),
                    workout.getString("level"),
                    workout.contains("ExNumber") ? Math.toIntExact(workout.getLong("ExNumber")) : 0,
                    workout.getString("url")
                );
                workouts.add(w);
            }

            System.out.println("Workouts lortu dira: " + workouts.size());

        } catch (Exception e) {
            System.err.println("Errorea workout-ak lortzean: " + e.getMessage());
        }

        return workouts;
    }

    // 🔹 Workout-ak lortu mailaren arabera (Beginner, Intermediate, Advanced...)
    public ArrayList<Workout> lortuWorkOutsLVL(String level) {
        ArrayList<Workout> workouts = new ArrayList<>();

        try {
            // Konexioa sortu
            KonexioaDB konexioa = new KonexioaDB();
            Firestore db = konexioa.konektatuDB();

            // Firestore-n "Beginner" maila "Begginer" bezala dago
            String dbLevel = level;
            if (level.equalsIgnoreCase("Beginner")) {
                dbLevel = "Begginer";
            }

            // Mailaren araberako kontsulta
            Query consulta = db.collection("workouts").whereEqualTo("level", dbLevel);
            ApiFuture<QuerySnapshot> query = consulta.get();
            List<QueryDocumentSnapshot> workoutList = query.get().getDocuments();

            // Workout objektuak sortu eta gehitu
            for (QueryDocumentSnapshot workout : workoutList) {
                Workout w = new Workout(
                    workout.getId(),
                    workout.getString("name"),
                    workout.getString("level"),
                    workout.contains("ExNumber") ? Math.toIntExact(workout.getLong("ExNumber")) : 0,
                    workout.getString("url")
                );
                workouts.add(w);
            }

            System.out.println("Filtratutako workouts: " + workouts.size());

        } catch (Exception e) {
            System.err.println("Errorea workout-ak lortzean mailaren arabera: " + e.getMessage());
        }

        return workouts;
    }
}
