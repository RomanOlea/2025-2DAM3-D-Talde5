package Vista;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import DatuController.UserDC;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class LoginV extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField tFIzena;
	private JTextField tFPasahitza;

	/**
	 * Create the frame.
	 */
	public LoginV() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JButton btnSaioaHasi = new JButton("Saioa Hasi");
		btnSaioaHasi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String email = tFIzena.getText();
				String psw = tFPasahitza.getText();

				UserDC userDC = new UserDC();
				if (email.isEmpty() || psw.isEmpty()) {
					JOptionPane.showMessageDialog(null, "Mesedez, bete eremu guztiak.");
					return;
				}
				if (userDC.loginDataOndo(email, psw)) {

					userDC.ErabiltzaileaLogeatu(email);
					try {
						System.out.println("Login ondo burutu da, orain WorkoutsV ireki behar da.");
						WorkoutsV frame = new WorkoutsV();
						frame.setVisible(true);
					} catch (Exception e2) {
						e2.printStackTrace();
					}

					dispose();

				} else {
					JOptionPane.showMessageDialog(null, "Kredentzialak ez dira zuzenak mezedez berriro saiatu");
				}
			}
		});
		btnSaioaHasi.setBounds(168, 179, 127, 23);
		contentPane.add(btnSaioaHasi);

		JButton btnErregistro = new JButton("Erregistratu");
		btnErregistro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ErregistroV erregistro = new ErregistroV();
				LoginV loginV = new LoginV();
				erregistro.setVisible(true);
				loginV.setVisible(false);
				dispose();
			}
		});
		btnErregistro.setBounds(168, 214, 127, 23);
		contentPane.add(btnErregistro);

		JLabel lblSaioaHasi = new JLabel("Saioa Hasi");
		lblSaioaHasi.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblSaioaHasi.setHorizontalAlignment(SwingConstants.CENTER);
		lblSaioaHasi.setBounds(177, 25, 104, 23);
		contentPane.add(lblSaioaHasi);

		JLabel lblIzena = new JLabel("Izena");
		lblIzena.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblIzena.setHorizontalAlignment(SwingConstants.CENTER);
		lblIzena.setBounds(50, 78, 89, 14);
		contentPane.add(lblIzena);

		JLabel lblPasahitza = new JLabel("Pasahitza:");
		lblPasahitza.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblPasahitza.setHorizontalAlignment(SwingConstants.CENTER);
		lblPasahitza.setBounds(50, 120, 89, 14);
		contentPane.add(lblPasahitza);

		tFIzena = new JTextField();
		tFIzena.setBounds(168, 78, 127, 17);
		contentPane.add(tFIzena);
		tFIzena.setColumns(10);

		tFPasahitza = new JTextField();
		tFPasahitza.setBounds(168, 120, 127, 17);
		contentPane.add(tFPasahitza);
		tFPasahitza.setColumns(10);

		ImageIcon icon = new ImageIcon("HeavySpace.png");
		Image img = icon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH); // Cambia 200x200 al tamaño deseado
		ImageIcon iconoEscalado = new ImageIcon(img);
		JLabel labelImagen = new JLabel(iconoEscalado);

		labelImagen.setBounds(320, 11, 104, 57);

		// Agregar el JLabel al panel de contenido
		contentPane.add(labelImagen);

	}
}
