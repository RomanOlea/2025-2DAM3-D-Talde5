package Vista;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

import DatuController.ExerciseDC;
import Modelo.AldagaiGlobalak;
import Modelo.AtzeraKontua;
import Modelo.Exercise;
import Modelo.Workout;
import Modelo.WorkoutHistory;
import Modelo.Kronometroa;

public class ExerciseV extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;

    private int currentExerciseIndex = 0;
    private ArrayList<Exercise> exercises;

    private AtzeraKontua kronometroSerie;
    private Kronometroa kronometroWorkout;
    private Kronometroa kronometroExercise; 
    private boolean pausado = false;

    private JLabel lblImage;

    private enum Fase { PRE_ARIKETA, ARIKETA, DESCANSO, NONE }
    private Fase faseAktuala = Fase.NONE;

    public ExerciseV() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 950, 600);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        setLocationRelativeTo(null);

        JLabel lblWorkoutIzena = new JLabel("Workout izena");
        lblWorkoutIzena.setFont(new Font("Tahoma", Font.BOLD, 32));
        lblWorkoutIzena.setHorizontalAlignment(SwingConstants.CENTER);
        lblWorkoutIzena.setBounds(34, 20, 300, 60);
        contentPane.add(lblWorkoutIzena);

        JTextPane lblAriketa = new JTextPane();
        lblAriketa.setEditable(false);
        lblAriketa.setBounds(360, 25, 540, 70);
        contentPane.add(lblAriketa);

        JTextPane lblWorkoutKrono = new JTextPane();
        lblWorkoutKrono.setEditable(false);
        lblWorkoutKrono.setBounds(34, 110, 183, 43);
        contentPane.add(lblWorkoutKrono);

        JTextPane lblSerieKronometro = new JTextPane();
        lblSerieKronometro.setEditable(false);
        lblSerieKronometro.setBounds(34, 170, 183, 43);
        contentPane.add(lblSerieKronometro);

        JTextPane lblDezkantuza = new JTextPane();
        lblDezkantuza.setEditable(false);
        lblDezkantuza.setBounds(34, 230, 183, 43);
        contentPane.add(lblDezkantuza);

        JTextPane lblAriketaKrono = new JTextPane();
        lblAriketaKrono.setEditable(false);
        lblAriketaKrono.setBounds(34, 290, 183, 43);
        contentPane.add(lblAriketaKrono);

        lblImage = new JLabel();
        lblImage.setBounds(500, 150, 400, 250);
        lblImage.setHorizontalAlignment(SwingConstants.CENTER);
        lblImage.setVerticalAlignment(SwingConstants.CENTER);
        contentPane.add(lblImage);

        JButton btnHasi = new JButton("Hasi");
        btnHasi.setBackground(new Color(51, 153, 0));
        btnHasi.setBounds(50, 400, 146, 38);
        contentPane.add(btnHasi);

        JButton btnAtera = new JButton("Atera");
        btnAtera.setBackground(Color.RED);
        btnAtera.setBounds(220, 400, 146, 38);
        contentPane.add(btnAtera);

        lblWorkoutIzena.setText(AldagaiGlobalak.autatutakoWorkouta.getName());
        kronometroWorkout = new Kronometroa();

        ExerciseDC exerciseDC = new ExerciseDC();
        Workout workout = AldagaiGlobalak.autatutakoWorkouta;
        exercises = exerciseDC.lortuAriketak(String.valueOf(workout.getId()));

        if (exercises != null && !exercises.isEmpty()) {
            erakutsiExercise(exercises.get(currentExerciseIndex));
        } else {
            JOptionPane.showMessageDialog(this, "Ez dago ariketarik workout honetan.");
            return;
        }

        Timer timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                lblWorkoutKrono.setText("Workout: " + kronometroWorkout.getSeg() + "s");

                if (currentExerciseIndex >= exercises.size()) return;

                Exercise currentExercise = exercises.get(currentExerciseIndex);
                lblAriketa.setText("ARIKETA: " + currentExercise.getName() +
                        " | DESC: " + currentExercise.getDescription() +
                        " | SERIE: " + currentExercise.getSeriesCount());

                if (!pausado) {
                    switch (faseAktuala) {

                        case PRE_ARIKETA:
                            lblSerieKronometro.setText("Hasi arte: " + kronometroSerie.getSeg());
                            if (!kronometroSerie.isAlive()) {
                                kronometroSerie = new AtzeraKontua(currentExercise.getDurationSeconds());
                                kronometroSerie.start();

                                kronometroExercise = new Kronometroa();
                                kronometroExercise.start();

                                faseAktuala = Fase.ARIKETA;
                            }
                            break;

                        case ARIKETA:
                            lblAriketaKrono.setText("Ariketa Krono: " + kronometroExercise.getSeg() + "s");
                            lblSerieKronometro.setText("Serie: " + kronometroSerie.getSeg());
                            if (!kronometroSerie.isAlive()) {
                                kronometroSerie = new AtzeraKontua(10); 
                                kronometroSerie.start();
                                faseAktuala = Fase.DESCANSO;
                            }
                            break;

                        case DESCANSO:
                            lblDezkantuza.setText("Deskantzu: " + kronometroSerie.getSeg());
                            if (!kronometroSerie.isAlive()) {
                                currentExerciseIndex++;
                                if (currentExerciseIndex < exercises.size()) {
                                    erakutsiExercise(exercises.get(currentExerciseIndex));
                                    if (kronometroExercise != null)
                                        kronometroExercise.resetKronometro();

                                    kronometroSerie = new AtzeraKontua(5);
                                    kronometroSerie.start();
                                    faseAktuala = Fase.PRE_ARIKETA;
                                } else {
                                    faseAktuala = Fase.NONE;
                                    btnHasi.setText("Amaitu workout-a");
                                }
                            }
                            break;

                        default:
                            break;
                    }
                }
            }
        });
        timer.start();

        btnHasi.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switch (btnHasi.getText()) {
                    case "Hasi":
                        kronometroWorkout.start();
                        kronometroSerie = new AtzeraKontua(5); 
                        kronometroSerie.start();
                        faseAktuala = Fase.PRE_ARIKETA;
                        pausado = false;
                        btnHasi.setText("Gelditu");
                        btnHasi.setBackground(new Color(0, 200, 255));
                        break;

                    case "Gelditu":
                        pausado = true;
                        if (kronometroWorkout != null) kronometroWorkout.stopKronometro();
                        if (kronometroExercise != null) kronometroExercise.stopKronometro();
                        btnHasi.setText("Reanudar");
                        btnHasi.setBackground(new Color(0, 255, 0));
                        break;

                    case "Reanudar":
                        pausado = false;
                        if (kronometroWorkout != null) kronometroWorkout.startKronometro();
                        if (kronometroExercise != null) kronometroExercise.startKronometro();
                        btnHasi.setText("Gelditu");
                        btnHasi.setBackground(new Color(0, 200, 255));
                        break;

                    case "Amaitu workout-a":
                        WorkoutHistory historialBerria = new WorkoutHistory(
                                AldagaiGlobalak.logeatutakoErabiltzailea.getEmail(),
                                new Date(),
                                kronometroWorkout.lortuSegunduak(),
                                Integer.parseInt(AldagaiGlobalak.autatutakoWorkouta.getId()),
                                currentExerciseIndex);

                        JOptionPane.showMessageDialog(ExerciseV.this,
                                "Workout amaituta!\nDenbora: " + kronometroWorkout.getSeg() + " segundu.");
                        dispose();
                        break;
                }
            }
        });

        btnAtera.addActionListener(e -> {
            try {
                WorkoutsV workoutsV = new WorkoutsV();
                workoutsV.setVisible(true);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            dispose();
        });
    }

    private void erakutsiExercise(Exercise ex) {
        if (ex.getPhoto() != null && !ex.getPhoto().isEmpty()) {
            erakutsiIrudia(ex.getPhoto());
        } else {
            lblImage.setIcon(null);
        }
    }

    private void erakutsiIrudia(String relativePath) {
        try {
            File file = new File(relativePath);
            if (!file.exists()) {
                System.out.println("❌ No se encuentra la imagen: " + file.getAbsolutePath());
                lblImage.setIcon(null);
                return;
            }

            ImageIcon icon = new ImageIcon(file.getAbsolutePath());
            Image scaled = icon.getImage().getScaledInstance(lblImage.getWidth(), lblImage.getHeight(), Image.SCALE_SMOOTH);
            lblImage.setIcon(new ImageIcon(scaled));
        } catch (Exception e) {
            lblImage.setIcon(null);
            System.out.println("⚠️ Error al cargar imagen: " + relativePath + " → " + e.getMessage());
        }
    }
}
