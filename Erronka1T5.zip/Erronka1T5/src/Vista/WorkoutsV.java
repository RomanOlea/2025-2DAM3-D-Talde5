package Vista;

import java.util.ArrayList;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.MouseInputAdapter;
import javax.swing.table.DefaultTableModel;

import DatuController.ExerciseDC;
import DatuController.WorkoutDC;
import Modelo.AldagaiGlobalak;
import Modelo.Exercise;
import Modelo.Workout;

import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;

public class WorkoutsV extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTable table;
    private ArrayList<Workout> workoutList;
    private ArrayList<Workout> workoutListAuxiliar;
    private WorkoutDC workoutData = new WorkoutDC();
    private ExerciseDC exerciseData = new ExerciseDC();
    private ArrayList<Exercise> ariketaList;

    public WorkoutsV() {
        workoutList = workoutData.lortuWorkout();
        if (workoutList == null) workoutList = new ArrayList<>();
        workoutListAuxiliar = new ArrayList<>();

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 991, 556);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // 🔹 Botón para volver al login
        JButton btnAtzera = new JButton("Loginera bueltatu");
        btnAtzera.addActionListener(e -> {
            dispose();
            try {
                LoginV frame = new LoginV();
                frame.setVisible(true);
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        });
        btnAtzera.setBounds(757, 39, 149, 23);
        contentPane.add(btnAtzera);

        // 🔹 Botón para abrir historial
        JButton btnHistoriala = new JButton("Historiala ikusi");
        btnHistoriala.addActionListener(e -> {
            try {
                if (AldagaiGlobalak.logeatutakoErabiltzailea != null) {
                    int userId = AldagaiGlobalak.logeatutakoErabiltzailea.getId(); // Asegúrate de tener getId()
                    WorkoutHistoryV frame = new WorkoutHistoryV(userId);
                    frame.setVisible(true);
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "Erabiltzailea ez dago logeatuta.");
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
        btnHistoriala.setBounds(757, 467, 154, 23);
        contentPane.add(btnHistoriala);

        // 🔹 Panel para mostrar ejercicios seleccionados
        JTextPane tPariketak = new JTextPane();
        tPariketak.setBounds(757, 108, 172, 329);
        contentPane.add(tPariketak);

        // 🔹 ComboBox para niveles
        JComboBox<String> cBmaila = new JComboBox<>();
        cBmaila.setBounds(294, 39, 164, 22);
        contentPane.add(cBmaila);

        // Llenar ComboBox según nivel de usuario
        String userLevel = (AldagaiGlobalak.logeatutakoErabiltzailea != null)
                ? AldagaiGlobalak.logeatutakoErabiltzailea.getLevel()
                : null;

        if (userLevel != null) {
            switch (userLevel) {
                case "Advanced":
                    cBmaila.addItem("Advanced"); cBmaila.addItem("Middle"); cBmaila.addItem("Beginner"); break;
                case "Middle":
                    cBmaila.addItem("Middle"); cBmaila.addItem("Beginner"); break;
                case "Beginner":
                    cBmaila.addItem("Beginner"); break;
                default:
                    cBmaila.addItem("Advanced"); cBmaila.addItem("Middle"); cBmaila.addItem("Beginner");
            }
        } else {
            cBmaila.addItem("Advanced"); cBmaila.addItem("Middle"); cBmaila.addItem("Beginner");
        }

        JLabel lblNewLabel = new JLabel("Level:");
        lblNewLabel.setBounds(250, 43, 69, 14);
        contentPane.add(lblNewLabel);

        // 🔹 Tabla de workouts
        String[] zutabeak = { "Name", "Exercise Number", "Level", "Url" };
        DefaultTableModel taulaModeloa = new DefaultTableModel(zutabeak, 0);
        table = new JTable(taulaModeloa);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(167, 108, 538, 329);
        contentPane.add(scrollPane);

        // 🔹 Botón iniciar workout
        JButton btnNewButton = new JButton("Workout-a hasi");
        btnNewButton.addActionListener(e -> {
            if (AldagaiGlobalak.autatutakoWorkouta != null) {
                try {
                    ExerciseV frame = new ExerciseV();
                    frame.setVisible(true);
                    dispose();
                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            } else {
                JOptionPane.showMessageDialog(this,
                        "Workout bat aukeratu mesedez, taulan ikusten duzun workout-ean klik eginez");
            }
        });
        btnNewButton.setBounds(409, 467, 154, 23);
        contentPane.add(btnNewButton);

        // Cargar tabla inicial
        if (cBmaila.getItemCount() > 0) {
            cBmaila.setSelectedIndex(0);
            populateModelByLevel(taulaModeloa, (String)cBmaila.getSelectedItem());
        }

        // Selección de workout en tabla
        table.addMouseListener(new MouseInputAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int row = table.getSelectedRow();
                if (row != -1) {
                    Workout selected = workoutListAuxiliar.get(row);
                    ariketaList = exerciseData.lortuAriketak(selected.getId());
                    AldagaiGlobalak.autatutakoAriketak = ariketaList;
                    AldagaiGlobalak.autatutakoWorkouta = selected;
                    tPariketak.setText("Workout honen ariketak:\n" + ariketaList.toString());
                }
            }
        });

        // Cambio de nivel en ComboBox
        cBmaila.addActionListener(e -> {
            String selected = (String) cBmaila.getSelectedItem();
            populateModelByLevel(taulaModeloa, selected);
        });
    }

    // 🔹 Filtra y carga los workouts según nivel
    private void populateModelByLevel(DefaultTableModel model, String level) {
        model.setRowCount(0);
        workoutListAuxiliar = new ArrayList<>();

        if (level == null) return;

        String normalized = level.trim().toLowerCase();
        for (Workout w : workoutList) {
            String lvl = w.getLevel();
            if (lvl == null) continue;

            switch (normalized) {
                case "advanced":
                    model.addRow(new Object[]{ w.getName(), w.getExerciseCount(), w.getLevel(), w.getUrl() });
                    workoutListAuxiliar.add(w);
                    break;
                case "middle":
                    if (lvl.equalsIgnoreCase("Middle") || lvl.equalsIgnoreCase("Beginner")) {
                        model.addRow(new Object[]{ w.getName(), w.getExerciseCount(), w.getLevel(), w.getUrl() });
                        workoutListAuxiliar.add(w);
                    }
                    break;
                case "beginner":
                    if (lvl.equalsIgnoreCase("Beginner")) {
                        model.addRow(new Object[]{ w.getName(), w.getExerciseCount(), w.getLevel(), w.getUrl() });
                        workoutListAuxiliar.add(w);
                    }
                    break;
            }
        }
    }
}
