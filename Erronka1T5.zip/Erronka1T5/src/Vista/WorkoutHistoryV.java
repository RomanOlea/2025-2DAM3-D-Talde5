package Vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import DatuController.WHistoryDC;
import Modelo.WorkoutHistory;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

public class WorkoutHistoryV extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTable table;
    private ArrayList<WorkoutHistory> historialList;
    private WHistoryDC workoutHistorialDC = new WHistoryDC();

    public WorkoutHistoryV(int userId) {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1020, 545);
        setTitle("Workout-en Historiala");

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JButton btnAtzera = new JButton("Atzera");
        btnAtzera.addActionListener((ActionEvent e) -> dispose());
        btnAtzera.setBounds(875, 29, 89, 23);
        contentPane.add(btnAtzera);

        JLabel lblNewLabel = new JLabel("WORKOUT-EN HISTORIALA");
        lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 32));
        lblNewLabel.setBounds(285, 29, 444, 57);
        contentPane.add(lblNewLabel);

        String[] zutabeak = { "Data", "Workout izena", "Maila", "Denbora (s)", "Progreso (%)" };
        DefaultTableModel taulaModeloa = new DefaultTableModel(zutabeak, 0);
        table = new JTable(taulaModeloa);
        table.setEnabled(false);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(100, 120, 800, 330);
        contentPane.add(scrollPane);

        JButton btnReload = new JButton("Eguneratu Historiala");
        btnReload.addActionListener(e -> kargatuHistoriala(userId, taulaModeloa));
        btnReload.setBounds(400, 470, 200, 25);
        contentPane.add(btnReload);

        // Cargar historial al iniciar
        kargatuHistoriala(userId, taulaModeloa);
    }

    private void kargatuHistoriala(int userId, DefaultTableModel taulaModeloa) {
        try {
            taulaModeloa.setRowCount(0);
            historialList = workoutHistorialDC.lortuHistorialak(userId);

            if (historialList == null || historialList.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Ez da aurkitu workout historiala.");
                System.out.println("⚠️ Historial vacío o nulo.");
                return;
            }

            for (WorkoutHistory historialW : historialList) {
                taulaModeloa.addRow(new Object[]{
                        historialW.getDate() != null ? historialW.getDate() : "N/A",
                        historialW.getName(),
                        historialW.getLevel(),
                        historialW.getTotalDuration(),
                        historialW.getPercentage()
                });
            }

            System.out.println("✅ Se cargaron " + historialList.size() + " workouts en la tabla.");

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Errorea historiala kargatzean: " + e.getMessage());
        }
    }
}
