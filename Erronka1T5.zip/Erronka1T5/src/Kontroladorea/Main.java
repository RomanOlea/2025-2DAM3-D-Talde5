package Kontroladorea;

import Vista.LoginV;

public class Main {
	
	public static void main(String[] args) {
		// Iniciar el programa
		LoginV login = new LoginV();
		login.setVisible(true);
	}

}
