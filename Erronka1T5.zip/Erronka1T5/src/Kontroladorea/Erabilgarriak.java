package Kontroladorea;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;

import Modelo.Exercise;
import Modelo.WorkoutHistory;

public class Erabilgarriak {
	
	public static Date dataBilakatu(String fechaStr) {
		SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
		try {
			return formato.parse(fechaStr);
		} catch (ParseException e) {
			System.out.println("Error al parsear la fecha: " + e.getMessage());
			return null;
		}
	}
	
	public ArrayList<Exercise> ariketaGuztiak(ArrayList<Exercise> ariketaList){
		ArrayList<Exercise> ariketakListAux = new ArrayList<Exercise>();
	    
		for(Exercise exercise : ariketaList) {
			int serieKop = exercise.getSeriesCount();
            for(int i = 0; i < serieKop; i++) {
            	ariketakListAux.add(exercise);
            }
        }
		return ariketakListAux;
	}
	
	public static ArrayList<WorkoutHistory> datarenAraberaOrdenatu(ArrayList<WorkoutHistory> lista) {
		Collections.sort(lista, new Comparator<WorkoutHistory>() {
			@Override
			public int compare(WorkoutHistory o1, WorkoutHistory o2) {
				return o2.getDate().compareTo(o1.getDate());
			}
		});
		return lista;
	}

}
