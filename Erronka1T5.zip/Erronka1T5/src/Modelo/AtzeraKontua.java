package Modelo;

public class AtzeraKontua extends Thread {

    private int seg; 
    private boolean pistuta = true; 
	private Boolean isOn = true;
	private Boolean isCountdown = true; 

    // 🔹 Hasierako segundoekin konstruktorea
    public AtzeraKontua(int segundos) {
        this.seg = segundos;
    }

    // 🔹 Atseden + ariketa segundoekin (aukera bezala)
    public AtzeraKontua(int descanso, int ariketa) {
        this.seg = ariketa;
    }

    @Override
    public void run() {
        // 🔹 Haria martxan dagoen bitartean eta segundoak > 0 direnean
        while (seg > 0 && pistuta) {
            try {
                Thread.sleep(1000); 
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            seg--;
        }
    }

    // 🔹 Gelditzen diren segundoak itzuli
    public int getSeg() {
        return seg;
    }

    // 🔹 Haria gelditu
    public void setPistuta(boolean p) {
        pistuta = p;
    }

    // 🔹 Kronometroa bizirik dagoen edo ez begiratu
    public boolean isAliveCustom() {
        return seg > 0 && pistuta;
    }
    
    // 🔹 Atzerako kontaketa aktibatuta dagoen edo ez
    public Boolean getIsCountdown() {
		return isCountdown;
	}
    
    // 🔹 Kronometroa gelditu
    public void stopKronometro() {
		isOn = false;
	}

    // 🔹 Kronometroa berriro hasi
	public void startKronometro() {
		isOn = true;
	}
}
