package Modelo;

import java.util.ArrayList;

public class AldagaiGlobalak {

	public static boolean konektatuta = false;

	public static User logeatutakoErabiltzailea;

	public static Workout autatutakoWorkouta;

	public static ArrayList<Exercise> autatutakoAriketak;

}
