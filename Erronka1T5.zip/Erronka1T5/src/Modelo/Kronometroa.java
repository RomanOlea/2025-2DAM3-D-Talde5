package Modelo;

public class Kronometroa extends Thread {

    private int cont = 0;
    private Boolean isOn = true;
    private Boolean pistuta = true;
    
	/** 🔹 Hilo que cuenta los segundos cada segundo */
    @Override
    public void run() {
        while (pistuta) {
            try {
                Thread.sleep(1000);
                if (isOn) {
                    this.cont++;
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.out.println("El hilo fue interrumpido.");
                break;
            }
        }
    }

    /** 🔹 Devuelve el tiempo formateado mm:ss */
    public String getSeg() {
        int seg = cont % 60;
        int min = cont / 60;
        return String.format("%02d:%02d", min, seg);
    }

    /** 🔹 Detiene temporalmente el cronómetro (pausa) */
    public void stopKronometro() {
        isOn = false;
    }

    /** 🔹 Reanuda el cronómetro después de pausar */
    public void startKronometro() {
        isOn = true;
    }

    /** 🔹 Devuelve si el hilo sigue vivo */
    public Boolean getPistuta() {
        return pistuta;
    }

    public void setPistuta(Boolean pistuta) {
        this.pistuta = pistuta;
    }

    /** 🔹 Devuelve los segundos totales transcurridos */
    public int lortuSegunduak() {
        return cont;
    }

    /** 🔹 Reinicia el cronómetro a 0 sin detener el hilo */
    public void resetKronometro() {
        cont = 0;
    }
}
