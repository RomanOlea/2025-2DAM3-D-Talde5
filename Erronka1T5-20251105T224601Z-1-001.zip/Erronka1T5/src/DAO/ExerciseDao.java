package DAO;

import java.util.ArrayList;
import java.util.List;

import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.CollectionReference;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.QueryDocumentSnapshot;

import Modelo.Exercise;
import Modelo.KonexioaDB;
import Modelo.Workout;
import DatuController.WorkoutDC;

public class ExerciseDao {

    // 🔹 Obtener ejercicios de un workout específico
    public ArrayList<Exercise> lortuWorkoutarenAriketak(String workoutId) {
        ArrayList<Exercise> exercises = new ArrayList<>();
        try {
            Firestore db = KonexioaDB.konektatuDB();
            DocumentReference docRef = db.collection("workouts").document(workoutId);
            ApiFuture<DocumentSnapshot> querySnapshot = docRef.get();
            DocumentSnapshot document = querySnapshot.get();

            if (document.exists()) {
                CollectionReference arCol = docRef.collection("Exercises");
                List<QueryDocumentSnapshot> ars = arCol.get().get().getDocuments();

                for (QueryDocumentSnapshot ar : ars) {
                    Exercise exercise = new Exercise(
                        Integer.parseInt(ar.getId()),
                        ar.getString("name"),
                        (ar.getLong("series")).intValue(),
                        (ar.getLong("repeticiones")).intValue(),
                        ar.getString("photo"),
                        (ar.getLong("time in seg")).intValue(),
                        Integer.parseInt(workoutId),
                        ar.getString("desc")
                    );
                    exercises.add(exercise);
                }
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return exercises;
    }

    // 🔹 Obtener todos los ejercicios de todos los workouts
    public ArrayList<Exercise> lortuAriketaGuztiak() {
        ArrayList<Exercise> ariketak = new ArrayList<>();
        WorkoutDC workoutDC = new WorkoutDC();
        ArrayList<Workout> workouts = workoutDC.lortuWorkout();

        try {
            Firestore db = KonexioaDB.konektatuDB();

            for (Workout w : workouts) {
                DocumentReference docRef = db.collection("workouts").document(w.getId());
                ApiFuture<DocumentSnapshot> querySnapshot = docRef.get();
                DocumentSnapshot document = querySnapshot.get();

                if (document.exists()) {
                    CollectionReference arCol = docRef.collection("Exercises");
                    List<QueryDocumentSnapshot> ars = arCol.get().get().getDocuments();

                    for (QueryDocumentSnapshot ar : ars) {
                        Exercise exercise = new Exercise(
                            Integer.parseInt(ar.getId()),
                            ar.getString("name"),
                            (ar.getLong("series")).intValue(),
                            (ar.getLong("repeticiones")).intValue(),
                            ar.getString("photo"),
                            (ar.getLong("time in seg")).intValue(),
                            Integer.parseInt(w.getId()),
                            ar.getString("desc")
                        );
                        ariketak.add(exercise);
                    }
                }
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return ariketak;
    }
}
