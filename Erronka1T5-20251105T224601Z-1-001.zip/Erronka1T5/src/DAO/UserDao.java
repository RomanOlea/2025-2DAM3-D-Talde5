package DAO;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.Query;
import com.google.cloud.firestore.QueryDocumentSnapshot;
import com.google.cloud.firestore.QuerySnapshot;
import com.google.cloud.firestore.CollectionReference;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.WriteResult;

import Modelo.KonexioaDB;
import Modelo.User;


public class UserDao {
	
	public boolean loginDataOndo(String email, String psw) {
		boolean loginOk = false;

		Firestore db = KonexioaDB.konektatuDB();

		try {
			Query consulta = db.collection("users").whereEqualTo("email", email).whereEqualTo("password", psw);
			ApiFuture<QuerySnapshot> querySnapshot = consulta.get();
			List<QueryDocumentSnapshot> documents = querySnapshot.get().getDocuments();

			if (!documents.isEmpty()) {
				loginOk = true;
			}
			db.close();

		} catch (Exception e) {
			System.out.println(e.getMessage());

		}

		return loginOk;
	}
	
	public void erabiltzaileaRegistratu(User erabiltzailea) {

		Firestore db = KonexioaDB.konektatuDB();


		CollectionReference users = db.collection("users");

		Map<String, Object> user = new HashMap<>();
		user.put("name", erabiltzailea.getName());
		user.put("lastName", erabiltzailea.getlastName());
		user.put("birth", erabiltzailea.getBirthDate());
		user.put("email", erabiltzailea.getEmail());
		user.put("password", erabiltzailea.getPassword());
		user.put("trainer", false);
		user.put("level", "Beginner");
		int id = UsuarioKop() + 1;
		DocumentReference usuarioNew = users.document("" + id + "");

		ApiFuture<WriteResult> writeResult = usuarioNew.set(user);

		CollectionReference historialCol = usuarioNew.collection("historialDeWorkouts");
		Map<String, Object> historial = new HashMap<>();
		historial.put("HISTORIAL", "EL DOCUMENTO N. 0 NO SE DEBE USAR, ES UNA REFERENCIA PARA CREAR EL HISTORIAL");
		DocumentReference historialDoc = historialCol.document("0");
		historialDoc.set(historial);

		try {

			System.out.println("Update time : " + writeResult.get().getUpdateTime());
			db.close();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public int UsuarioKop() {
		int kop = 0;
		Firestore db = KonexioaDB.konektatuDB();


		try {
			ApiFuture<QuerySnapshot> query = db.collection("users").get();
			QuerySnapshot querySnapshot = query.get();
			List<QueryDocumentSnapshot> Usuarios = querySnapshot.getDocuments();
			kop = Usuarios.size();

			db.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return kop;
	}
	
	
	public int lortuId(String email) {
		int id = 0;
		Firestore db = KonexioaDB.konektatuDB();


		try {
			Query consulta = db.collection("users").whereEqualTo("email", email);
			ApiFuture<QuerySnapshot> querySnapshot = consulta.get();
			List<QueryDocumentSnapshot> documents = querySnapshot.get().getDocuments();
			for (QueryDocumentSnapshot document : documents) {
				id = Integer.parseInt(document.getId());
			}
			db.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return id;
	}

	
	
	public ArrayList<User> lortuErabiltzaileak() {
		ArrayList<User> erabiltzaileak = new ArrayList<User>();

		Firestore db = KonexioaDB.konektatuDB();


		try {

			ApiFuture<QuerySnapshot> query = db.collection("users").get();

			QuerySnapshot querySnapshot = query.get();
			List<QueryDocumentSnapshot> Usuarios = querySnapshot.getDocuments();

			for (QueryDocumentSnapshot document : Usuarios) {

				User erabiltzailea = new User(lortuId(document.getString("email")),
						document.getString("name"), document.getString("lastName"), document.getString("email"),
						document.getString("password"), document.getBoolean("trainer"),
						document.getDate("birth"), document.getString("level"));
				erabiltzaileak.add(erabiltzailea);
			}
			db.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return erabiltzaileak;
	}

	
	public User lortuErabiltzailea(String email) {
		User user = null;

		Firestore db = KonexioaDB.konektatuDB();


		try {
			Query consulta = db.collection("users").whereEqualTo("email", email);
			ApiFuture<QuerySnapshot> querySnapshot = consulta.get();
			List<QueryDocumentSnapshot> document = querySnapshot.get().getDocuments();

			user = new User(lortuId(document.getFirst().getString("email")),
					document.getFirst().getString("name"), document.getFirst().getString("lastName"), document.getFirst().getString("email"),
					document.getFirst().getString("password"), document.getFirst().getBoolean("trainer"),
					document.getFirst().getDate("birth"), document.getFirst().getString("level"));

			db.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return user;
	}
	
	
	public boolean emailArtuta(String email) {
		boolean emailArtuta = false;
		Firestore db = KonexioaDB.konektatuDB();


		try {
			Query consulta = db.collection("users").whereEqualTo("email", email);
			ApiFuture<QuerySnapshot> querySnapshot = consulta.get();
			List<QueryDocumentSnapshot> documents = querySnapshot.get().getDocuments();

			if (!documents.isEmpty()) {
				emailArtuta = true;
			}
			db.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return emailArtuta;

	}

}
