package DAO;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.CollectionReference;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.Query;
import com.google.cloud.firestore.QueryDocumentSnapshot;
import com.google.cloud.firestore.QuerySnapshot;

import Modelo.KonexioaDB;
import Modelo.WorkoutHistory;

public class WorkoutHistoryDao {

    // 🔹 Obtiene todos los workouts históricos de un usuario
	 public ArrayList<WorkoutHistory> lortuHistorialak(int userId) {
	        ArrayList<WorkoutHistory> historialak = new ArrayList<>();

	        try {
	            Firestore db = KonexioaDB.konektatuDB();

	            // 🔹 Ajusta el nombre del campo según Firestore
	            Query consulta = db.collection("workoutHistory")
	                               .whereEqualTo("userId", userId);

	            ApiFuture<QuerySnapshot> query = consulta.get();
	            List<QueryDocumentSnapshot> dokumentuak = query.get().getDocuments();

	            for (QueryDocumentSnapshot d : dokumentuak) {
	                WorkoutHistory h = new WorkoutHistory(
	                    d.getId(),
	                    d.getLong("userId").intValue(),
	                    d.getString("workoutName"),
	                    d.getString("date"),
	                    d.getString("duration")
	                );
	                historialak.add(h);
	            }

	            System.out.println("Historial encontrado: " + historialak.size() + " entradas para userId " + userId);

	        } catch (Exception e) {
	            System.err.println("Errorea historial lortzean: " + e.getMessage());
	            e.printStackTrace();
	        }

	        return historialak;
	    }

    // 🔹 Añade un nuevo registro al historial
    public void gehituHistoriala(int userId, WorkoutHistory historial) throws Exception {
        Firestore db = null;
        try {
        	db = KonexioaDB.konektatuDB();


            CollectionReference historialRef = db.collection("users")
                    .document(String.valueOf(userId))
                    .collection("historicalWorkouts");

            // Firestore genera un id único automáticamente
            DocumentReference newHistorial = historialRef.document();

            Map<String, Object> data = new HashMap<>();
            data.put("date", historial.getDate());
            data.put("level", historial.getLevel());
            data.put("workoutName", historial.getName());
            data.put("time", historial.getTotalDuration());
            data.put("percentage", historial.getPercentage());

            newHistorial.set(data).get();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (db != null) db.close();
        }
    }
}
