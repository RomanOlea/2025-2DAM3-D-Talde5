package DAO;

import java.util.ArrayList;
import java.util.List;
import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.QueryDocumentSnapshot;
import com.google.cloud.firestore.QuerySnapshot;
import Modelo.KonexioaDB;
import Modelo.Workout;

public class WorkoutsDao {

    // 🔹 Obtener todos los workouts
    public ArrayList<Workout> lortuWorkOuts() {
        ArrayList<Workout> workouts = new ArrayList<>();
        try {
            Firestore db = KonexioaDB.konektatuDB();

            ApiFuture<QuerySnapshot> query = db.collection("workouts").get();
            List<QueryDocumentSnapshot> workoutList = query.get().getDocuments();

            for (QueryDocumentSnapshot workout : workoutList) {
                Workout w = new Workout(
                    workout.getId(),
                    workout.getString("name"),
                    workout.getString("level"),
                    workout.contains("ExNumber") ? Math.toIntExact(workout.getLong("ExNumber")) : 0,
                    workout.getString("url")
                );
                workouts.add(w);
            }

            System.out.println("Workouts obtenidos: " + workouts.size());

        } catch (Exception e) {
            System.err.println("Error obteniendo workouts: " + e.getMessage());
        }
        return workouts;
    }

    // 🔹 Obtener workouts filtrados por nivel
    public ArrayList<Workout> lortuWorkOutsLVL(String nivelSeleccionado) {
        ArrayList<Workout> filtrados = new ArrayList<>();
        try {
            ArrayList<Workout> todos = lortuWorkOuts(); // todos los workouts

            if (nivelSeleccionado == null) nivelSeleccionado = "";

            String nivelSel = nivelSeleccionado.trim().toLowerCase();

            for (Workout w : todos) {
                if (w.getLevel() == null) continue;

                String nivelWorkout = w.getLevel().trim().toLowerCase();
                if (nivelWorkout.equals("Begginer")) nivelWorkout = "Beginner"; // corregir typo

                boolean mostrar = false;
                switch (nivelSel) {
                    case "Advanced":
                        mostrar = true; // mostrar todos
                        break;
                    case "Middle":
                        if (nivelWorkout.equals("Middle") || nivelWorkout.equals("Beginner")) mostrar = true;
                        break;
                    case "Begginer":
                        if (nivelWorkout.equals("Begginer")) mostrar = true;
                        break;
                }

                if (mostrar) filtrados.add(w);
            }

            System.out.println("Workouts filtrados por nivel '" + nivelSeleccionado + "': " + filtrados.size());

        } catch (Exception e) {
            System.err.println("Error filtrando workouts por nivel: " + e.getMessage());
        }
        return filtrados;
    }
}
