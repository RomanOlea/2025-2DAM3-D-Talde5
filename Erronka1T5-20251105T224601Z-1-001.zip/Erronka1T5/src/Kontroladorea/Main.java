package Kontroladorea;

import Modelo.KonexioaDB;
import Vista.LoginV;

public class Main {
	
	public static void main(String[] args) {
	    Runtime.getRuntime().addShutdownHook(new Thread(() -> {
	        System.out.println("Cerrando Firestore...");
	        KonexioaDB.closeDB();
	    }));

	    LoginV login = new LoginV();
	    login.setVisible(true);
	}


}
