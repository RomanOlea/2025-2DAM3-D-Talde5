package DatuController;

import java.util.ArrayList;

import DAO.ExerciseDao;
import Modelo.AldagaiGlobalak;
import Modelo.Exercise;

public class ExerciseDC {
	
	public ArrayList<Exercise> lortuAriketak(String id) {
		ArrayList<Exercise> exerciseList = null;
		
		if (AldagaiGlobalak.konektatuta) {
			ExerciseDao arDao = new ExerciseDao();
			exerciseList = arDao.lortuWorkoutarenAriketak(id);
			
		} else {
//			BackUpDat baDat = new BackUpDat();
//			exerciseList = baDat.lortuAriketakIdarenBitartez(Integer.parseInt(id));
		}

		return exerciseList;
	}

}
