package DatuController;

import java.util.ArrayList;
import DAO.WorkoutsDao;
import Modelo.AldagaiGlobalak;
import Modelo.Workout;

public class WorkoutDC {

    // 🔹 Devuelve todos los workouts
    public ArrayList<Workout> lortuWorkout() {
        ArrayList<Workout> workoutList = new ArrayList<>();
        if (AldagaiGlobalak.konektatuta) {
            WorkoutsDao woDao = new WorkoutsDao();
            workoutList = woDao.lortuWorkOuts();
        }
        return workoutList;
    }

    // 🔹 Devuelve workouts filtrados por nivel
    public ArrayList<Workout> lortuWorkoutMailarenArabera(String level) {
        ArrayList<Workout> workoutList = new ArrayList<>();
        if (AldagaiGlobalak.konektatuta) {
            WorkoutsDao woDao = new WorkoutsDao();
            workoutList = woDao.lortuWorkOutsLVL(level);
        }
        return workoutList;
    }
}
