package DatuController;

import DAO.UserDao;
import Modelo.AldagaiGlobalak;

public class UserDC {

	public void ErabiltzaileaLogeatu(String email) {

		UserDao userDao = new UserDao();

		AldagaiGlobalak.logeatutakoErabiltzailea = userDao.lortuErabiltzailea(email);
	}
	
	
	public boolean loginDataOndo(String email, String psw) {
		boolean loginOk = true;
		
		if(AldagaiGlobalak.konektatuta) {
			UserDao userDao = new UserDao();
			loginOk = userDao.loginDataOndo(email, psw);
			loginOk = true;
		} 
		
		return loginOk;
	} 

}
