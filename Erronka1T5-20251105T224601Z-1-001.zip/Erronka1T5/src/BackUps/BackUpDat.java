//package BackUps;
//
//import java.io.FileInputStream;
//import java.io.FileOutputStream;
//import java.io.IOException;
//import java.io.ObjectInputStream;
//import java.io.ObjectOutputStream;
//import java.util.ArrayList;
//
//import com.google.cloud.firestore.Firestore;
//
//import DAO.ExerciseDao;
//import DAO.UserDao;
//import DAO.WorkoutsDao;
//import Modelo.AldagaiGlobalak;
//import Modelo.Exercise;
//import Modelo.KonexioaDB;
//import Modelo.User;
//import Modelo.Workout;
//
//public class BackUpDat extends Thread {
//	
//	String bideaEr = "Erabiltzaileak.dat";
//	String bideaWo = "Workoutak.dat";
//	String bideaAr = "Ariketak.dat";
//	Boolean stopHilo = false;
//
//	UserDao usDao;
//	WorkoutsDao woDao;
//	ExerciseDao exDao; 
//	
//	@Override
//	public void run() {
//
//		while (!stopHilo) {
//
//			try {
//				KonexioaDB connection = new KonexioaDB();
//				Firestore db = connection.konektatuDB();
//				for (int i = 0; i < 60; i++) {
//					Thread.sleep(500);
//					if (connection.isInternetAvailable()) { 
//						AldagaiGlobalak.konektatuta = true;
//					} else {
//						AldagaiGlobalak.konektatuta = false;
//					}
//				}
//				
//				if (connection.isInternetAvailable()) {
//					usDao = new UserDao();
//					woDao = new WorkoutsDao();
//					exDao = new ExerciseDao();
////					hWoDao = new ExerciseDao();
//					idatziDatuak(woDao.lortuWorkOuts(), exDao.lortuAriketaGuztiak(), usDao.lortuErabiltzaileak());
//					//backUpXML.idatziDatuak(hWoDao.lortuHistorialak());
//					System.out.println("Konektatuta!");
//
//				} else {
//					System.out.println("Ez dago konexiorik");
//				}
//
//				connection.closeDB(db);
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
//		}
//
//	}
//
//	public User lortuErabiltzailea(String email) {
//		User us = null;
//
//		ArrayList<User> erabiltzaileList = lortuErabiltzaileak();
//
//		for (User user : erabiltzaileList) {
//			if (user.getEmail().equals(email)) {
//				us = user;
//			}
//		}
//
//		return us;
//	}
//	
//	
//	public void idatziDatuak(ArrayList<Workout> workoutList, ArrayList<Exercise> exerciseList,
//			ArrayList<User> userList) {
//
//		// Erabiltzaileen datuak idatzi
//		try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(bideaEr))) {
//			oos.writeObject(userList); // Serializa el objeto y lo guarda en el archivo
//			System.out.println("Objeto guardado en " + bideaEr);
//		} catch (IOException e) {
//			System.out.println("Error al escribir el objeto: " + e.getMessage());
//		}
//
//		// Workouten datuak idatzi
//		try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(bideaWo))) {
//			oos.writeObject(workoutList); // Serializa el objeto y lo guarda en el archivo
//			System.out.println("Objeto guardado en " + bideaWo);
//		} catch (IOException e) {
//			System.out.println("Error al escribir el objeto: " + e.getMessage());
//		}
//
//		// Workouten datuak idatzi
//		try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(bideaAr))) {
//			oos.writeObject(exerciseList); // Serializa el objeto y lo guarda en el archivo
//			System.out.println("Objeto guardado en " + bideaAr);
//		} catch (IOException e) {
//			System.out.println("Error al escribir el objeto: " + e.getMessage());
//		}
//
//	}
//	
//	public ArrayList<User> lortuErabiltzaileak() {
//		ArrayList<User> us = null;
//
//		try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(bideaEr))) {
//			us = (ArrayList<User>) ois.readObject();
//
//		} catch (Exception e) {
//			System.out.println(e.getMessage());
//		}
//
//		return us;
//	}
//
//	public ArrayList<Workout> lortuWorkoutak(String level) {
//		ArrayList<Workout> wo = new ArrayList<Workout>();
//		ArrayList<Workout> woAux = null;
//
//		try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(bideaWo))) {
//			woAux = (ArrayList<Workout>) ois.readObject();
//		} catch (Exception e) {
//			System.out.println(e.getMessage());
//		}
//
//		switch (level) {
//
//		case "Advandced":
//
//			for (int i = 0; i < woAux.size(); i++) {
//				if (woAux.get(i).getLevel().equals("advandced")) {
//					wo.add(woAux.get(i));
//				}
//			}
//
//		case "Middle":
//
//			for (int i = 0; i < woAux.size(); i++) {
//				if (woAux.get(i).getLevel().equals("Middle")) {
//					wo.add(woAux.get(i));
//				}
//			}
//
//		case "Begginner":
//
//			for (int i = 0; i < woAux.size(); i++) {
//				if (woAux.get(i).getLevel().equals("Begginner")) {
//					wo.add(woAux.get(i));
//				}
//			}
//
//		}
//
//		return wo;
//	}
//	
//	public ArrayList<Workout> lortuWorkoutsLvl(String level) {
//		ArrayList<Workout> workoutList = new ArrayList<Workout>();
//
//		workoutList = lortuWorkoutak(level);
//		ArrayList<Workout> workoutListSailkatuta = new ArrayList<Workout>();
//
//		for (int i = 0; i < workoutList.size(); i++) {
//			if (workoutList.get(i).getLevel().equals(level)) {
//				workoutListSailkatuta.add(workoutList.get(i));
//			}
//		}
//
//		return workoutListSailkatuta;
//	}
//	
//	public ArrayList<Exercise> lortuAriketak() {
//		ArrayList<Exercise> ar = null;
//
//		try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(bideaAr))) {
//			ar = (ArrayList<Exercise>) ois.readObject();
//
//		} catch (Exception e) {
//			System.out.println(e.getMessage());
//		}
//
//		return ar;
//	}
//
//	public ArrayList<Exercise> lortuAriketakIdarenBitartez(int id) {
//		ArrayList<Exercise> ar = null;
//		ArrayList<Exercise> arZailkatuta = new ArrayList<Exercise>();
//		try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(bideaAr))) {
//			ar = (ArrayList<Exercise>) ois.readObject();
//			
//		} catch (Exception e) {
//			System.out.println(e.getMessage());
//		}
//
//		for (int i = 0; i < ar.size(); i++) {
//
//			if (ar.get(i).getWorkoutId() == id) {
//				arZailkatuta.add(ar.get(i));
//			}
//		}
//
//		if (arZailkatuta == null) {
//			System.out.println("Sartutako id-a ez dauka ariketarik ala ez da existitzen");
//		} 
//
//		return arZailkatuta;
//	}
//
//	public boolean loginDataOndo(String email, String psw) {
//		boolean login = false;
//		ArrayList<User> erabiltzaileList = new ArrayList<User>();
//		erabiltzaileList = lortuErabiltzaileak();
//
//		for (int i = 0; i < erabiltzaileList.size(); i++) {
//			if (erabiltzaileList.get(i).getEmail().equals(email) && erabiltzaileList.get(i).getPassword().equals(psw)) {
//				login = true;
//			}
//		}
//
//		return login;
//	}
//
//}
