package Vista;

import java.util.ArrayList;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.MouseInputAdapter;
import javax.swing.table.DefaultTableModel;

import DatuController.ExerciseDC;
import DatuController.WorkoutDC;
import Modelo.AldagaiGlobalak;
import Modelo.Exercise;
import Modelo.Workout;

import java.awt.event.MouseEvent;

public class WorkoutsV extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTable table;
    private ArrayList<Workout> workoutList;
    private ArrayList<Workout> workoutListAuxiliar;
    private WorkoutDC workoutData = new WorkoutDC();
    private ExerciseDC exerciseData = new ExerciseDC();
    private ArrayList<Exercise> ariketaList;

    public WorkoutsV() {
        // 🔹 Cargar workouts
        workoutList = workoutData.lortuWorkout();
        if (workoutList == null) workoutList = new ArrayList<>();
        workoutListAuxiliar = new ArrayList<>();

        System.out.println("Total workouts cargados: " + workoutList.size());
        for (Workout w : workoutList) {
            System.out.println("Workout: " + w.getName() + ", Level: " + w.getLevel());
        }

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 991, 556);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // 🔹 Botón volver login
        JButton btnAtzera = new JButton("Loginera bueltatu");
        btnAtzera.addActionListener(e -> {
            dispose();
            try {
                LoginV frame = new LoginV();
                frame.setVisible(true);
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        });
        btnAtzera.setBounds(757, 39, 149, 23);
        contentPane.add(btnAtzera);

        // 🔹 Panel ejercicios
        JTextPane tPariketak = new JTextPane();
        tPariketak.setBounds(757, 108, 172, 329);
        contentPane.add(tPariketak);

        // 🔹 ComboBox niveles
        JComboBox<String> cBmaila = new JComboBox<>();
        cBmaila.setBounds(294, 39, 164, 22);
        contentPane.add(cBmaila);

        // 🔹 Llenar niveles según usuario
        String userLevel = (AldagaiGlobalak.logeatutakoErabiltzailea != null)
                ? AldagaiGlobalak.logeatutakoErabiltzailea.getLevel()
                : null;

        if (userLevel != null) {
            switch (userLevel.toLowerCase()) {
                case "advanced":
                    cBmaila.addItem("Advanced");
                    cBmaila.addItem("Middle");
                    cBmaila.addItem("Beginner");
                    break;
                case "middle":
                    cBmaila.addItem("Middle");
                    cBmaila.addItem("Beginner");
                    break;
                case "beginner":
                case "begginer":
                    cBmaila.addItem("Beginner");
                    break;
                default:
                    cBmaila.addItem("Advanced");
                    cBmaila.addItem("Middle");
                    cBmaila.addItem("Beginner");
            }
        } else {
            cBmaila.addItem("Advanced");
            cBmaila.addItem("Middle");
            cBmaila.addItem("Beginner");
        }

        JLabel lblNewLabel = new JLabel("Level:");
        lblNewLabel.setBounds(250, 43, 69, 14);
        contentPane.add(lblNewLabel);

        // 🔹 Tabla workouts
        String[] columnas = {"Name", "Exercise Number", "Level", "Url"};
        DefaultTableModel taulaModeloa = new DefaultTableModel(columnas, 0);
        table = new JTable(taulaModeloa);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(167, 108, 538, 329);
        contentPane.add(scrollPane);

        // 🔹 Botón iniciar workout
        JButton btnHasi = new JButton("Workout-a hasi");
        btnHasi.setBounds(409, 467, 154, 23);
        contentPane.add(btnHasi);
        btnHasi.addActionListener(e -> {
            if (AldagaiGlobalak.autatutakoWorkouta != null) {
                ExerciseV frame = new ExerciseV();
                frame.setVisible(true);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this,
                        "Workout bat aukeratu mesedez, taulan ikusten duzun workout-ean klik eginez");
            }
        });

        // 🔹 Selección workout en tabla
        table.addMouseListener(new MouseInputAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int row = table.getSelectedRow();
                if (row != -1) {
                    Workout selected = workoutListAuxiliar.get(row);
                    ariketaList = exerciseData.lortuAriketak(selected.getId());
                    AldagaiGlobalak.autatutakoAriketak = ariketaList;
                    AldagaiGlobalak.autatutakoWorkouta = selected;

                    StringBuilder sb = new StringBuilder();
                    for (Exercise ex : ariketaList) {
                        sb.append(ex.getName()).append("\n");
                    }
                    tPariketak.setText("Workout honen ariketak:\n" + sb.toString());
                }
            }
        });

        // 🔹 Cambio de nivel ComboBox
        cBmaila.addActionListener(e -> {
            String selected = (String) cBmaila.getSelectedItem();
            populateModelByLevel(taulaModeloa, selected);
        });

        // 🔹 Cargar tabla inicial
        if (cBmaila.getItemCount() > 0) {
            cBmaila.setSelectedIndex(0);
            populateModelByLevel(taulaModeloa, (String) cBmaila.getSelectedItem());
        }
    }

    // 🔹 Filtrar workouts según nivel
    private void populateModelByLevel(DefaultTableModel model, String level) {
        model.setRowCount(0);
        workoutListAuxiliar.clear();

        if (level == null || level.isEmpty()) return;

        String normalizedSelected = level.trim().toLowerCase();
        System.out.println("User selected level: " + normalizedSelected);

        for (Workout w : workoutList) {
            if (w.getLevel() == null) continue;

            String lvl = w.getLevel().trim().toLowerCase();
            if (lvl.equals("begginer")) lvl = "beginner";

            boolean mostrar = false;
            switch (normalizedSelected) {
                case "advanced":
                    mostrar = true;
                    break;
                case "middle":
                    if (lvl.equals("middle") || lvl.equals("beginner")) mostrar = true;
                    break;
                case "beginner":
                    if (lvl.equals("beginner")) mostrar = true;
                    break;
            }

            if (mostrar) {
                model.addRow(new Object[]{w.getName(), w.getExerciseCount(), w.getLevel(), w.getUrl()});
                workoutListAuxiliar.add(w);
            }
        }

        System.out.println("populateModelByLevel: " + workoutListAuxiliar.size() + " workouts mostrados.");
    }
}
