package Vista;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextPane;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JOptionPane;

import Kontroladorea.Erabilgarriak;
import Modelo.AldagaiGlobalak;
import Modelo.AtzeraKontua;
import Modelo.Exercise;
import Modelo.Kronometroa;
import Modelo.WorkoutHistory;

public class ExerciseV extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;

    private int ariketaKont = 0;
    private ArrayList<Exercise> ariketaList;

    private AtzeraKontua kronometro; // cuenta regresiva para pre-ejercicio y descanso
    private Kronometroa kronometroWorkout; // cronómetro total del workout
    private Kronometroa kronometroAriketa; // cronómetro específico por ejercicio

    private int seriesRestantes = 3; // contador de series por ejercicio
    private JTextPane lblSerieContador;

    private enum Fase { PRE_ARIKETA, ARIKETA, DESCANSO, NONE }
    private Fase faseAktuala = Fase.NONE;

    private boolean pausado = false;

    public ExerciseV() {
        Erabilgarriak er = new Erabilgarriak();
        ariketaList = er.ariketaGuztiak(AldagaiGlobalak.autatutakoAriketak);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 922, 443);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Labels
        JTextPane lblAriketa = new JTextPane();
        lblAriketa.setEditable(false);
        lblAriketa.setBounds(243, 25, 428, 73);
        contentPane.add(lblAriketa);

        JTextPane lblWorkoutKrono = new JTextPane();
        lblWorkoutKrono.setEditable(false);
        lblWorkoutKrono.setBounds(34, 116, 183, 43);
        contentPane.add(lblWorkoutKrono);

        JTextPane lblSerieKronometro = new JTextPane();
        lblSerieKronometro.setEditable(false);
        lblSerieKronometro.setBounds(34, 176, 183, 43);
        contentPane.add(lblSerieKronometro);

        lblSerieContador = new JTextPane();
        lblSerieContador.setEditable(false);
        lblSerieContador.setBounds(243, 176, 183, 43);
        contentPane.add(lblSerieContador);
        lblSerieContador.setText("Series restantes: " + seriesRestantes);

        JTextPane lblDezkantuza = new JTextPane();
        lblDezkantuza.setEditable(false);
        lblDezkantuza.setBounds(34, 234, 183, 43);
        contentPane.add(lblDezkantuza);

        JTextPane lblAriketaKrono = new JTextPane();
        lblAriketaKrono.setEditable(false);
        lblAriketaKrono.setBounds(366, 109, 183, 43);
        contentPane.add(lblAriketaKrono);

        JButton btnHasi = new JButton("Hasi");
        btnHasi.setBackground(new Color(51, 153, 0));
        btnHasi.setBounds(57, 310, 146, 38);
        contentPane.add(btnHasi);

        JButton btnAtera = new JButton("Atera");
        btnAtera.setBackground(new Color(255, 0, 0));
        btnAtera.setBounds(243, 310, 146, 38);
        contentPane.add(btnAtera);

        // Cronómetros
        kronometroWorkout = new Kronometroa();
        kronometroAriketa = new Kronometroa(); // cronómetro por ejercicio

        // Timer de actualización de UI
        Timer timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Cronómetro total
                lblWorkoutKrono.setText("Workout Denb Tot: " + kronometroWorkout.getSeg());

                if (ariketaKont >= ariketaList.size()) return;

                Exercise currentExercise = ariketaList.get(ariketaKont);
                lblAriketa.setText("ARIKETA: " + currentExercise.getName() +
                        " | DESC: " + currentExercise.getDescription() +
                        " | SERIE: " + currentExercise.getSeriesCount());

                // Cronómetro individual del ejercicio
                lblAriketaKrono.setText("Ariketaren kronometroa: " + kronometroAriketa.getSeg());

                if (!pausado) {
                    switch (faseAktuala) {
                        case PRE_ARIKETA:
                            lblSerieKronometro.setText("Hasi arte: " + (kronometro != null ? kronometro.getSeg() : 0));
                            if (kronometro == null || !kronometro.isAlive()) {
                                kronometro = new AtzeraKontua(5);
                                kronometro.start();
                                faseAktuala = Fase.ARIKETA;
                                kronometroAriketa.restart(); // reinicia cronómetro por ejercicio
                            }
                            break;

                        case ARIKETA:
                            lblSerieKronometro.setText("Serie kronometroa: " + (kronometro != null ? kronometro.getSeg() : 0));
                            if (kronometro != null && !kronometro.isAlive()) {
                                // Termina una serie
                                seriesRestantes--;
                                lblSerieContador.setText("Series restantes: " + seriesRestantes);

                                kronometro = new AtzeraKontua(10); // descanso
                                kronometro.start();
                                faseAktuala = Fase.DESCANSO;
                            }
                            break;

                        case DESCANSO:
                            lblDezkantuza.setText("Deskantzu: " + (kronometro != null ? kronometro.getSeg() : 0));
                            if (kronometro != null && !kronometro.isAlive()) {
                                if (seriesRestantes > 0) {
                                    // Todavía quedan series del mismo ejercicio
                                    kronometro = new AtzeraKontua(5); // pre-ariketa
                                    kronometro.start();
                                    faseAktuala = Fase.PRE_ARIKETA;
                                } else {
                                    // Todas las series completadas: pasar al siguiente ejercicio
                                    ariketaKont++;
                                    if (ariketaKont < ariketaList.size()) {
                                        // Reiniciar series y cronómetro del nuevo ejercicio
                                        seriesRestantes = 3; 
                                        lblSerieContador.setText("Series restantes: " + seriesRestantes);

                                        kronometro = new AtzeraKontua(5); // pre-ariketa del nuevo ejercicio
                                        kronometro.start();
                                        faseAktuala = Fase.PRE_ARIKETA;

                                        kronometroAriketa.restart(); // reinicia cronómetro para el nuevo ejercicio
                                    } else {
                                        // Workout terminado
                                        faseAktuala = Fase.NONE;
                                        btnHasi.setText("Amaitu workout-a");
                                    }
                                }
                            }
                            break;

                        case NONE:
                            break;
                    }
                }
            }
        });
        timer.start();

        // Botón Hasi / Gelditu / Reanudar / Terminar
        btnHasi.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switch (btnHasi.getText()) {
                    case "Hasi":
                        kronometroWorkout.start();
                        kronometroAriketa.restart(); // cronómetro por ejercicio inicia
                        kronometro = new AtzeraKontua(5);
                        kronometro.start();
                        faseAktuala = Fase.PRE_ARIKETA;
                        pausado = false;
                        btnHasi.setText("Gelditu");
                        btnHasi.setBackground(new Color(0, 200, 255));
                        break;

                    case "Gelditu":
                        if (kronometro != null) kronometro.setPistuta(false);
                        kronometroWorkout.stopKronometro();
                        kronometroAriketa.stopKronometro();
                        pausado = true;
                        btnHasi.setText("Reanudar");
                        btnHasi.setBackground(new Color(0, 255, 0));
                        break;

                    case "Reanudar":
                        if (kronometro != null) kronometro.startKronometro();
                        kronometroWorkout.startKronometro();
                        kronometroAriketa.startKronometro();
                        pausado = false;
                        btnHasi.setText("Gelditu");
                        btnHasi.setBackground(new Color(0, 200, 255));
                        break;

                    case "Amaitu workout-a":
                        JOptionPane.showMessageDialog(ExerciseV.this,
                                "Workout amaituta!\nAriketak: " + AldagaiGlobalak.autatutakoAriketak.size() +
                                "\nDenbora totala: " + kronometroWorkout.getSeg() + " seg");
                        dispose();
                        break;
                }
            }
        });

        // Botón salir
        btnAtera.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                kronometroWorkout.setPistuta(false);
                kronometroAriketa.stopKronometro();
                try {
                    WorkoutsV workoutsV = new WorkoutsV();
                    workoutsV.setVisible(true);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                dispose();
            }
        });
    }
}
