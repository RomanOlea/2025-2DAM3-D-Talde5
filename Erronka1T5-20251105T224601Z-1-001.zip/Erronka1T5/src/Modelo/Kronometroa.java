package Modelo;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;

import javax.swing.JOptionPane;

import Vista.ExerciseV;
import Vista.WorkoutsV;

public class Kronometroa extends Thread {

	private int cont = 0;
	private Boolean isOn = true;
	private Boolean pistuta = true;

	public Kronometroa() {
	}

	public Kronometroa(int durationSeconds) {
	}

	@Override
	public void run() {
		while (pistuta) {
			try {
				Thread.sleep(1000);
				if (isOn == true) {
					this.cont++;
				}
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				System.out.println("El hilo fue interrumpido.");
				break;
			}
		}
	}
	
	

	public String getSeg() {
		String denbora;
		double seg = cont % 60;
		double min = cont / 60;

		denbora = String.format("%02d:%02d", (int) min, (int) seg);

		return denbora;
	}

	public void stopKronometro() {
		isOn = false;
	}

	public void startKronometro() {
		isOn = true;
	}

	public Boolean getPistuta() {
		return pistuta;
	}

	public void setPistuta(Boolean pistuta) {
		this.pistuta = pistuta;
	}

	public int lortuSegunduak() {
		return cont;
	}
	
	public void restart() {
        this.cont = 0;
        this.isOn = true;
        this.pistuta = true;
        // Si el hilo no está vivo, arrancarlo de nuevo
        if (!this.isAlive()) {
            this.start();
        }
    }

	
	
	
}
