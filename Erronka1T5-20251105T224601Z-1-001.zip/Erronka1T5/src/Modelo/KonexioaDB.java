package Modelo;

import java.io.File;
import java.io.FileInputStream;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.FirestoreOptions;

public class KonexioaDB {

    private static Firestore dbInstance = null;

    // ✅ Método estático que mantiene una sola conexión activa
    public static synchronized Firestore konektatuDB() {
        if (dbInstance == null) {
            try {
                File serviceFile = new File("DBGYMAPP.json");
                if (!serviceFile.exists()) {
                    AldagaiGlobalak.konektatuta = false;
                    System.out.println("No se encontró el archivo DBGYMAPP.json");
                    return null;
                }

                FileInputStream serviceAcc = new FileInputStream(serviceFile);
                FirestoreOptions firestoreOptions = FirestoreOptions.getDefaultInstance()
                        .toBuilder()
                        .setProjectId("empleadosbd-7f34f")
                        .setCredentials(GoogleCredentials.fromStream(serviceAcc))
                        .build();

                dbInstance = firestoreOptions.getService();
                AldagaiGlobalak.konektatuta = true;
                System.out.println("✅ Conexión a Firestore establecida correctamente.");

            } catch (Exception e) {
                System.out.println("❌ Error al conectar con Firestore: " + e.getMessage());
                e.printStackTrace();
                AldagaiGlobalak.konektatuta = false;
            }
        }

        return dbInstance;
    }

    // ❌ Ya NO se debe cerrar Firestore mientras se use la app
    public static void closeDB() {
        try {
            if (dbInstance != null) {
                dbInstance.close();
                dbInstance = null;
                System.out.println("⚠️ Conexión Firestore cerrada manualmente.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
