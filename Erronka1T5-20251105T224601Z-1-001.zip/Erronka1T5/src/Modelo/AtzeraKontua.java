package Modelo;

public class AtzeraKontua extends Thread {

    private int seg; // segundos restantes
    private boolean pistuta = true; // para controlar si el hilo sigue corriendo
	private Boolean isOn = true;
		private Boolean isCountdown = true;

    // Constructor con segundos iniciales
    public AtzeraKontua(int segundos) {
        this.seg = segundos;
    }

    // Constructor con segundos de descanso + segundos de ariketa (si quieres usarlo así)
    public AtzeraKontua(int descanso, int ariketa) {
        this.seg = ariketa; // Por defecto, toma los segundos de ariketa
    }

    @Override
    public void run() {
        while (seg > 0 && pistuta) {
            try {
                Thread.sleep(1000); // espera 1 segundo
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            seg--; // resta 1 segundo
        }
    }

    // Devuelve los segundos restantes
    public int getSeg() {
        return seg;
    }

    // Detener el hilo
    public void setPistuta(boolean p) {
        pistuta = p;
    }

    // Comprueba si el cronómetro sigue corriendo
    public boolean isAliveCustom() {
        return seg > 0 && pistuta;
    }
    
    public Boolean getIsCountdown() {
		return isCountdown;
	}
    
    public void stopKronometro() {
		isOn = false;
	}

	public void startKronometro() {
		isOn = true;
	}
}
